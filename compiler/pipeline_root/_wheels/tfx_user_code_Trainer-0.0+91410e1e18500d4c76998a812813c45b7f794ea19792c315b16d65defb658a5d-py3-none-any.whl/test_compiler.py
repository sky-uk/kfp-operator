from compiler import compiler
from click.testing import CliRunner
import yaml
import os
import sys

runner = CliRunner()
config_file_path = 'acceptance/pipeline_conf.yaml'
output_file_path = 'acceptance/pipeline.yaml'

def test_cli():
    sys.path.append("acceptance")
    result = runner.invoke(compiler.compile, ['--pipeline_config', config_file_path, '--output_file', output_file_path])

    print(result.output)
    assert result.exit_code == 0
    assert os.stat(output_file_path).st_size != 0


def test_failure():
    result = runner.invoke(compiler.compile, ['not_existing.yaml', 'pipeline.yaml'])
    assert result.exit_code != 0
    assert os.path.isfile(output_file_path) == False